import numpy as np
import matplotlib.pyplot as plt

# Définition de la fonction et cible
a, b, c = 0.5, 10, 3
f = lambda x: a*x**2 + b*x + c*np.sin(4*np.pi*x) + 10*np.exp(-100*(x - 0.5)**2)
target = 6.94
tol = 1e-3



# -------------------------
# Intégration Lebesgue
# -------------------------
def lebesgue_integral(N_y, M_x=100):
    x = np.linspace(0, 1, M_x)
    y = f(x)
    ymin, ymax = y.min(), y.max()
    levels = np.linspace(ymin, ymax, N_y)
    integral = 0
    dx = x[1] - x[0]
    for i in range(N_y-1):
        mask = (y >= levels[i]) & (y < levels[i+1])
        measure = np.sum(mask) * dx
        integral += measure * levels[i]
    return integral


# Suite de Cauchy pour déterminer N_y optimal
N_y = 10
I_prev = 0
while True:
    I = lebesgue_integral(N_y)
    if abs(I - I_prev) < tol:
        break
    I_prev = I
    N_y += 1

print("🔹 Méthode Lebesgue avec suite de Cauchy")
print(f"N_y optimal = {N_y}")
print(f"Intégrale estimée = {I:.5f}")
print(f"Erreur = {abs(I-target):.1e}")
