import numpy as np
import matplotlib.pyplot as plt

# Définition de la fonction et cible
a, b, c = 0.5, 10, 3
f = lambda x: a*x**2 + b*x + c*np.sin(4*np.pi*x) + 10*np.exp(-100*(x - 0.5)**2)
target = 6.94
tol = 1e-3

# -------------------------
# Tracé de la fonction f(x)
# -------------------------
x_plot = np.linspace(0, 1, 1000)
y_plot = f(x_plot)
plt.plot(x_plot, y_plot, label="f(x)")
plt.title("Fonction f(x)")
plt.xlabel("x")
plt.ylabel("f(x)")
plt.grid()
plt.savefig("f1_maillage_fonction.png")
plt.show()

# -------------------------
# Approximation numérique de la 2ème dérivée f''
# -------------------------
def f2(x):
    h = 1e-5
    return (f(x + h) - 2*f(x) + f(x - h)) / h**2

# -------------------------
# Génération du maillage adaptatif
# -------------------------
h_min, h_max = 0.001, 0.1  # tailles minimale et maximale des éléments
epsilon = tol

x_nodes = [0.0]  # point de départ
while x_nodes[-1] < 1.0:
    xi = x_nodes[-1]
    # calcul de la métrique locale
    lmbd = np.clip(1/epsilon * abs(f2(xi)), 1/h_max**2, 1/h_min**2)
    dx = 1 / np.sqrt(lmbd)
    if xi + dx > 1.0:
        dx = 1.0 - xi  # s'assurer de ne pas dépasser 1
    x_nodes.append(xi + dx)
x_nodes = np.array(x_nodes)

# -------------------------
# Tracé du maillage adaptatif
# -------------------------
plt.plot(x_plot, f(x_plot), label="f(x)")
plt.scatter(x_nodes, f(x_nodes), color='red', label="Maillage adaptatif")
plt.title("Maillage adaptatif basé sur f''(x)")
plt.xlabel("x")
plt.ylabel("f(x)")
plt.legend()
plt.grid()
plt.savefig("f1_maillage_adaptatif.png")
plt.show()

# -------------------------
# Intégration Riemann sur le maillage adaptatif
# -------------------------
y_nodes = f(x_nodes)
dx_nodes = np.diff(x_nodes)
I_adapt = np.sum(y_nodes[:-1] * dx_nodes)

print("🔹 Intégration sur maillage adaptatif")
print(f"Nombre de points = {len(x_nodes)}")
print(f"Intégrale estimée = {I_adapt:.5f}")
print(f"Erreur = {abs(I_adapt - target):.1e}")
