import numpy as np
import matplotlib.pyplot as plt

# ===============================
# Définition de la fonction f2(x)
# ===============================
f2 = lambda x: 1 / np.sqrt(1 - x**2)

# Tracé de la fonction f2(x)

x = np.linspace(-0.999, 0.999, 1000)  # éviter les singularités aux bornes
y = f2(x)

plt.figure(figsize=(8, 5))
plt.plot(x, y, color='b', label=r'$f_2(x) = \frac{1}{\sqrt{1-x^2}}$')
plt.title("Fonction f₂(x)")
plt.xlabel("x")
plt.ylabel("f₂(x)")
plt.grid(True)
plt.legend()
plt.tight_layout()

# 🔹 Sauvegarde de la figure
plt.savefig("f2_fonction.png", dpi=300)
plt.show()


# ===============================
# Méthode de Riemann pour f2
# ===============================
def riemann_integral_f2(N):
    x = np.linspace(-0.999, 0.999, N)  # éviter les bornes ±1
    y = f2(x)
    dx = 2 / (N - 1)
    return np.sum(y) * dx


# ===============================
# Paramètres de précision
# ===============================
target = np.pi
tol = 1e-3
N = 10

# Pour le graphique de convergence
Ns = []
Is = []
Erreurs = []

# ===============================
# Boucle d'approximation
# ===============================
while True:
    I = riemann_integral_f2(N)
    erreur = abs(I - target)
    Ns.append(N)
    Is.append(I)
    Erreurs.append(erreur)
    
    print(f"N = {N}, Intégrale = {I:.5f}, Erreur = {erreur:.1e}")
    
    if erreur < tol:
        print("\n🔹 Méthode de Riemann (f₂)")
        print(f"N optimal = {N}")
        print(f"Intégrale estimée = {I:.5f}")
        print(f"Erreur = {erreur:.1e}")
        break
    N += 1




  
