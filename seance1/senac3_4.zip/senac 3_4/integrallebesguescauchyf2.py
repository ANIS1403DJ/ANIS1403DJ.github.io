import numpy as np
import matplotlib.pyplot as plt

# Définition de la fonction f2(x)
f2 = lambda x: 1 / np.sqrt(1 - x**2)
target = np.pi  # valeur exacte
tol = 1e-3

# Méthode Lebesgue
def lebesgue_integral_f2(N_y, M_x=200):
    x = np.linspace(-0.999, 0.999, M_x)  # éviter singularités
    y = f2(x)
    ymin, ymax = y.min(), y.max()
    levels = np.linspace(ymin, ymax, N_y)
    integral = 0
    dx = x[1] - x[0]
    for i in range(N_y-1):
        mask = (y >= levels[i]) & (y < levels[i+1])
        measure = np.sum(mask) * dx
        integral += measure * levels[i]
    return integral

# Suite de Cauchy pour déterminer N_y optimal
N_y = 10
I_prev = 0
while True:
    I_l = lebesgue_integral_f2(N_y)
    if abs(I_l - I_prev) < tol:
        break
    I_prev = I_l
    N_y += 1

print("🔹 Méthode Lebesgue avec suite de Cauchy pour f2")
print(f"N_y optimal = {N_y}")
print(f"Intégrale estimée = {I_l:.5f}")
print(f"Erreur = {abs(I_l - target):.1e}")

