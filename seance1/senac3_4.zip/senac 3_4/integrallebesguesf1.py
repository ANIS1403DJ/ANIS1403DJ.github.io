import numpy as np
import matplotlib.pyplot as plt

# Définition de la fonction
a = 0.5
b = 10
c = 3
f = lambda x: a*x**2 + b*x + c*np.sin(4*np.pi*x) + 10*np.exp(-100*(x - 0.5)**2)

# Saisie de N pour le tracé
N = int(input("Donner une valeur pour N : "))

# Tracé de la fonction
x = np.linspace(0, 1, N)
y = f(x)
plt.plot(x, y)
plt.title("Fonction f(x)")
plt.xlabel("x")
plt.ylabel("y")
plt.grid()
plt.savefig("f1_lebesgue_plot.png")
plt.show()

# -------------------------
# Méthode Lebesgue
# -------------------------
def lebesgue_integral(N, M):
    x = np.linspace(0, 1, M)
    y = f(x)
    ymin, ymax = np.min(y), np.max(y)
    dy = (ymax - ymin) / (N - 1)
    levels = np.linspace(ymin, ymax, N)
    integral = 0
    for i in range(N - 1):
        mask = (y >= levels[i]) & (y < levels[i + 1])
        measure = np.sum(mask) * (1 / (M - 1))
        integral += measure * levels[i]
    return integral

# Paramètres
target_lebesgue = 6.94
tol_lebesgue = 1e-3
N_l = 100
M_l = 50

# Boucle pour trouver M optimal
while True:
    I_l = lebesgue_integral(N_l, M_l)
    erreur_I_l = abs(I_l - target_lebesgue)
    if erreur_I_l < tol_lebesgue:
        break
    M_l += 1

print(f"M optimal = {M_l}")
print(f"Intégrale estimée = {I_l:.5f}")
print(f"Erreur = {erreur_I_l:.1e}")
