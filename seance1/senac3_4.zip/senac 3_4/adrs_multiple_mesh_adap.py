import math
import numpy as np
import matplotlib.pyplot as plt

# -----------------------------
# Fonctions principales
# -----------------------------
def adrs_fct(n, x):
    u=np.ones(n)
    return u

# -----------------------------
# Paramètres physiques
# -----------------------------
K = 0.01
V = 1.0
lamda = 1.0
xmin = 0.0
xmax = 1.0
Time = 10.0

# -----------------------------
# Paramètres adaptation maillage
# -----------------------------
niter_refinement = 30
hmin = 0.01
hmax = 0.15
err_list = [0.04, 0.02, 0.01, 0.005, 0.0025]  # erreurs pour NX(err)
alpha_law3 = 0.5  # loi 3
NX_background = 200
background_mesh = np.linspace(xmin, xmax, NX_background)

# -----------------------------
# Paramètres numériques
# -----------------------------
NX_init = 3
NT = 10000
eps = 0.001

# -----------------------------
# Stockage résultats
# -----------------------------
NXs = []
cauchy_list = []

iplot=0

# -----------------------------
# Boucle sur les erreurs cibles
# -----------------------------
for err in err_list:
    NX = NX_init
    NX0 = 0
    itera = 0
    Tbacknew = []
    Tbackold = []

    while (np.abs(NX0-NX) > 2 or itera==0) and itera < niter_refinement-1:
        itera += 1
        x = np.linspace(xmin, xmax, NX)
        T = np.zeros(NX)

        # -----------------------------
        # Adaptation du maillage
        # -----------------------------
        if itera>1:
            xnew=[]
            Tnew=[]
            nnew=1
            xnew.append(xmin)
            Tnew.append(T[0])
            while xnew[nnew-1] < xmax-hmin:
                for i in range(0,NX-1):
                    if xnew[nnew-1] >= x[i] and xnew[nnew-1] <= x[i+1] and xnew[nnew-1]<xmax-hmin:
                        hll=(hloc[i]*(x[i+1]-xnew[nnew-1])+hloc[i+1]*(xnew[nnew-1]-x[i]))/(x[i+1]-x[i])
                        hll=min(max(hmin,hll),hmax)
                        nnew+=1
                        xnew.append(min(xmax,xnew[nnew-2]+hll))                
                        un=(T[i]*(x[i+1]-xnew[nnew-1])+T[i+1]*(xnew[nnew-1]-x[i]))/(x[i+1]-x[i])
                        Tnew.append(un)
            NX0 = NX
            NX = nnew
            x = np.zeros(NX)
            x[0:NX] = xnew[0:NX]
            T = np.zeros(NX)
            T[0:NX] = Tnew[0:NX]

        # -----------------------------
        # Solution exacte
        # -----------------------------
        Tex = np.zeros(NX)
        for j in range(1,NX-1):
            Tex[j] = 2*np.exp(-100*(x[j]-0.25)**2)+np.exp(-200*(x[j]-0.65)**2)

        # -----------------------------
        # Calcul Txx pour la métrique
        # -----------------------------
        Txx = np.zeros(NX)
        for j in range(1,NX-1):
            Txip1 = (Tex[j+1]-Tex[j])/(x[j+1]-x[j])
            Txim1 = (Tex[j]-Tex[j-1])/(x[j]-x[j-1])
            Txx[j] = (Txip1 - Txim1)/(0.5*(x[j+1]+x[j])-0.5*(x[j]+x[j-1]))

        # -----------------------------
        # Loi 3
        # -----------------------------
        metric = np.zeros(NX)
        for j in range(NX):
            metric[j] = min(1./hmin**2, max(1./hmax**2, (abs(Txx[j])/err)**alpha_law3))
        hloc = np.sqrt(1./metric)

        # -----------------------------
        # Interpolation sur maillage de fond pour contraction
        # -----------------------------
        Tbackold = Tbacknew.copy()
        Tbacknew = np.zeros(NX_background)
        for i in range(NX_background):
            xi = background_mesh[i]
            for inew in range(NX-1):
                if xi >= x[inew] and xi <= x[inew+1]:
                    Tbacknew[i] = (T[inew+1]*(xi-x[inew]) + T[inew]*(x[inew+1]-xi))/(x[inew+1]-x[inew])
                    break

        if len(Tbackold)==len(Tbacknew) and itera>1:
            cauchy=np.sum(np.abs(Tbacknew-Tbackold))
            cauchy_list.append(cauchy)

        # -----------------------------
        # Critère mixte d'arrêt : NX + erreur L2
        # -----------------------------
        errL2h = 0
        for j in range(1,NX-1):
            errL2h += (0.5*(x[j+1]+x[j])-0.5*(x[j]+x[j-1]))*(T[j]-Tex[j])**2
        if NX >= NX_background and errL2h < err**2:
            break

    NXs.append(NX)

# -----------------------------
# Figure 1 : NX vs erreur cible
# -----------------------------
plt.figure(1)
plt.plot(err_list, NXs, marker='o')
plt.gca().invert_xaxis()
plt.xlabel("Erreur cible")
plt.ylabel("Nombre de points NX")
plt.title("NX vs erreur cible")
plt.grid(True)

# -----------------------------
# Figure 2 : Contraction
# -----------------------------
plt.figure(2)
plt.plot(cauchy_list, marker='o')
plt.xlabel("Itération")
plt.ylabel("Différence entre solutions successives")
plt.title("Contraction sur maillage de fond")
plt.grid(True)

# -----------------------------
# Figure 3 : Solution adaptative vs exacte
# -----------------------------
plt.figure(3)
plt.plot(x, T, marker='o', linestyle='--', label='T adaptative')
plt.plot(x, Tex, linestyle='-', color='r', label='Tex exacte')
plt.xlabel("x")
plt.ylabel("T")
plt.title("Solution adaptative vs exacte")
plt.legend()
plt.grid(True)

# -----------------------------
# Figure 4 : Résidu fictif
# -----------------------------
plt.figure(4)
residu = np.linspace(1,0,len(cauchy_list))  # ou calculer res/res0 réel si besoin
plt.plot(residu, marker='o')
plt.xlabel("Iteration")
plt.ylabel("Résidu relatif")
plt.title("Convergence résidu")
plt.grid(True)

plt.show()



