import numpy as np
import matplotlib.pyplot as plt

# Définition de la fonction f(x)
a = 0.5
b = 10
c = 3
f = lambda x: a*x**2 + b*x + c*np.sin(4*np.pi*x) + 10*np.exp(-100*(x - 0.5)**2)

# Tracé de la fonction
x = np.linspace(0, 1, 1000)
y = f(x)
plt.plot(x, y)
plt.title("fonction f(x)")
plt.xlabel("x")
plt.ylabel("y")
plt.grid()
plt.savefig("f1_plot.png")
plt.show()

# 🔹 Méthode Riemann
def riemann_integral(N):
    x = np.linspace(0, 1, N)
    y = f(x)
    dx = (1 - 0) / (N - 1)
    return np.sum(y) * dx

# Paramètres de précision
target = 6.94
tol = 1e-3
N = 10

# Boucle sans limite
while True:
    I = riemann_integral(N)
    erreur = abs(I - target)
    print(f"N = {N}, Intégrale = {I:.5f}, Erreur = {erreur:.1e}")
    if erreur < tol:
        print("\n🔹 Méthode Riemann")
        print(f"N optimal = {N}")
        print(f"Intégrale estimée = {I:.5f}")
        print(f"Erreur = {erreur:.1e}")
        break
    N += 1
  





    




