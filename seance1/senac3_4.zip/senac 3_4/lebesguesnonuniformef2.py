import numpy as np
import matplotlib.pyplot as plt

# ===============================
# Définition de la fonction f2(x)
# ===============================
f2 = lambda x: 1 / np.sqrt(1 - x**2)
target = np.pi   # valeur exacte de l'intégrale sur [-1,1]
tol = 1e-3       # tolérance souhaitée

# ===============================
# Approximation numérique de la 2ème dérivée
# ===============================
def f2_second_derivative(x):
    h = 1e-5
    return (f2(x + h) - 2*f2(x) + f2(x - h)) / h**2

# ===============================
# Paramètres de maillage adaptatif
# ===============================
h_min, h_max = 0.001, 0.05
epsilon = tol

# ===============================
# Génération du maillage adaptatif
# ===============================
x_nodes = [-0.999]  # départ à -0.999 pour éviter singularité
while x_nodes[-1] < 0.999:
    xi = x_nodes[-1]
    lmbd = np.clip(1/epsilon * abs(f2_second_derivative(xi)), 1/h_max**2, 1/h_min**2)
    dx = 1 / np.sqrt(lmbd)
    if xi + dx > 0.999:
        dx = 0.999 - xi
    x_nodes.append(xi + dx)
x_nodes = np.array(x_nodes)

# ===============================
# Tracé du maillage adaptatif avec sauvegarde
# ===============================
x_plot = np.linspace(-0.999, 0.999, 1000)
plt.figure(figsize=(8,5))
plt.plot(x_plot, f2(x_plot), label="f2(x)")
plt.scatter(x_nodes, f2(x_nodes), color='red', label="Maillage adaptatif")
plt.title("Maillage adaptatif pour f2(x)")
plt.xlabel("x")
plt.ylabel("f2(x)")
plt.legend()
plt.grid()
plt.tight_layout()
plt.savefig("f2_maillage_adaptatif.png", dpi=300)  # sauvegarde du graphique
plt.show()

# ===============================
# Intégration Riemann sur le maillage adaptatif
# ===============================
y_nodes = f2(x_nodes)
dx_nodes = np.diff(x_nodes)
I_adapt = np.sum(y_nodes[:-1] * dx_nodes)

print("\n🔹 Intégration sur maillage adaptatif pour f2")
print(f"Nombre de points = {len(x_nodes)}")
print(f"Intégrale estimée = {I_adapt:.5f}")
print(f"Erreur = {abs(I_adapt - target):.1e}")
