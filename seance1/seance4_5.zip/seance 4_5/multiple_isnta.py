import numpy as np
import matplotlib.pyplot as plt
import math
import os

# -------------------------------
# Paramètres physiques
# -------------------------------
V = 1.0
K = 0.01
lamda = 1.0
Time = 2.0
freq = 2 * math.pi * 3

# -------------------------------
# Paramètres du maillage adaptatif
# -------------------------------
niter_refinement = 10
hmin = 0.01
hmax = 0.5
err = 0.01
NX = 10
NT = 1000

# -------------------------------
# Dossier pour sauvegarder les figures
# -------------------------------
fig_dir = "figures"
os.makedirs(fig_dir, exist_ok=True)

# -------------------------------
# Boucle sur les deux stratégies de métrique
# -------------------------------
for metric_insta in [False, True]:
    errorL2 = []
    hloc = np.ones(NX) * hmax * 0.5
    itera = 0
    NX0 = 0

    while abs(NX0 - NX) > -10 and itera < niter_refinement:
        itera += 1
        x = np.linspace(0, 1.0, NX)
        T = np.zeros(NX)

        # Adaptation du maillage
        if itera > 0:
            xnew = [0.0]
            Tnew = [T[0]]
            nnew = 1
            while xnew[nnew - 1] < 1.0 - hmin:
                for i in range(NX - 1):
                    if xnew[nnew - 1] >= x[i] and xnew[nnew - 1] <= x[i + 1]:
                        hll = (hloc[i] * (x[i + 1] - xnew[nnew - 1]) + hloc[i + 1] * (xnew[nnew - 1] - x[i])) / (x[i + 1] - x[i])
                        hll = min(max(hmin, hll), hmax)
                        xnew.append(min(1.0, xnew[nnew - 1] + hll))
                        un = (T[i] * (x[i + 1] - xnew[nnew]) + T[i + 1] * (xnew[nnew] - x[i])) / (x[i + 1] - x[i])
                        Tnew.append(un)
                        nnew += 1
                        break
            NX0 = NX
            NX = nnew
            x = np.array(xnew)
            T = np.array(Tnew)

        F = np.zeros(NX)
        RHS = np.zeros(NX)
        hloc = np.ones(NX) * hmax * 0.5
        metric = np.zeros(NX)
        Tex = np.exp(-20 * (x - 0.5)**2)

        # Calcul du terme source et du pas de temps
        dt = 1.e30
        for j in range(1, NX - 1):
            Tx = (Tex[j + 1] - Tex[j - 1]) / (x[j + 1] - x[j - 1])
            Txip1 = (Tex[j + 1] - Tex[j]) / (x[j + 1] - x[j])
            Txim1 = (Tex[j] - Tex[j - 1]) / (x[j] - x[j - 1])
            Txx = (Txip1 - Txim1) / (0.5 * (x[j + 1] + x[j]) - 0.5 * (x[j] + x[j - 1]))
            F[j] = V * Tx - K * Txx + lamda * Tex[j]
            dt = min(dt, 0.25 * (x[j + 1] - x[j - 1])**2 / (V * abs(x[j + 1] - x[j - 1]) + 4 * K + abs(F[j]) * (x[j + 1] - x[j - 1])**2))

        # Boucle temporelle
        t = 0.0
        for n in range(NT):
            if t >= Time:
                break
            dt = min(dt, Time - t)
            t += dt
            for j in range(1, NX - 1):
                visnum = 0.25 * (x[j + 1] - x[j - 1]) * abs(V)
                xnu = K + visnum
                Tx = (T[j + 1] - T[j - 1]) / (x[j + 1] - x[j - 1])
                Txip1 = (T[j + 1] - T[j]) / (x[j + 1] - x[j])
                Txim1 = (T[j] - T[j - 1]) / (x[j] - x[j - 1])
                Txx = (Txip1 - Txim1) / (0.5 * (x[j + 1] + x[j]) - 0.5 * (x[j] + x[j - 1]))
                src = F[j] * np.sin(freq * t) + Tex[j] * np.cos(freq * t) * freq
                RHS[j] = dt * (-V * Tx + xnu * Txx - lamda * T[j] + src)
                if metric_insta:
                    metric[j] += min(1. / hmin**2, max(1. / hmax**2, abs(Txx) / err))
                elif not metric_insta and (n == NT or t >= Time):
                    metric[j] = min(1. / hmin**2, max(1. / hmax**2, abs(Txx) / err))

            metric[0] = metric[1]
            metric[NX - 1] = metric[NX - 2]
            for j in range(1, NX - 1):
                T[j] += RHS[j]
                RHS[j] = 0
            T[0] = 0
            T[NX - 1] = 2 * T[NX - 2] - T[NX - 3]

        # Moyenne temporelle de la métrique
        if metric_insta:
            metric /= NT
        hloc = np.sqrt(1. / metric)

        # Calcul des erreurs
        errL2h = 0
        for j in range(1, NX - 1):
            errL2h += (0.5 * (x[j + 1] + x[j]) - 0.5 * (x[j] + x[j - 1])) * (T[j] - Tex[j])**2
        errorL2.append(errL2h)

        print(f"metric_insta={metric_insta}, itération={itera}, erreur L2 = {errL2h:.4e}")

    # Tracé de la solution finale
    plt.figure(figsize=(8, 5))
    plt.plot(x, T, 'o-', label='Solution Numérique')
    plt.plot(x, Tex, '-', label='Solution Exacte')
    plt.xlabel('x')
    plt.ylabel('T(x)')
    plt.title(f'Maillage adaptatif - metric_insta={metric_insta}')
    plt.legend()
    plt.grid(True)
    fname = f"adaptive_mesh_metric_insta_{metric_insta}.png"
    plt.savefig(os.path.join(fig_dir, fname), dpi=300)
    plt.show()

# Tracé des erreurs L2
plt.figure(figsize=(8, 5))
plt.plot(errorL2, 'o-', label='Erreur L2')
plt.xlabel("Itération d'adaptation")
plt.ylabel("Erreur L2")
plt.title("Erreur finale ADRS - maillage adaptatif")
plt.grid(True)
plt.savefig(os.path.join(fig_dir, "error_L2_adaptive.png"), dpi=300)
plt.show()