import numpy as np
import matplotlib.pyplot as plt
import math
import os

# ------------------------------------------------------------
#  ADRS 1D instationnaire avec solution exacte connue
# ------------------------------------------------------------

V = 1.0           
K = 0.1           
lamda = 1.0       
L = 1.0           
Tmax = 1.0        
omega = 4 * math.pi  

# Dossier pour sauvegarder les figures
fig_dir = "figures"
os.makedirs(fig_dir, exist_ok=True)

# Solution exacte et source
def exact_solution(x, t):
    return np.exp(-lamda*t) * np.sin(2*np.pi*x) * np.sin(omega*t)

def source_term(x, t):
    u_t = np.exp(-lamda*t) * np.sin(2*np.pi*x) * (omega*np.cos(omega*t) - lamda*np.sin(omega*t))
    u_x = np.exp(-lamda*t) * 2*np.pi*np.cos(2*np.pi*x) * np.sin(omega*t)
    u_xx = -np.exp(-lamda*t) * (2*np.pi)**2 * np.sin(2*np.pi*x) * np.sin(omega*t)
    return u_t + V*u_x - K*u_xx + lamda*exact_solution(x,t)

# Listes pour les erreurs
NX_list = [21, 41, 81, 161]
Err_T2, Err_Tfin = [], []

# Boucle sur maillages
for NX in NX_list:
    x = np.linspace(0, L, NX)
    dx = x[1] - x[0]
    dt = dx**2 / (V*dx + K + dx**2)
    nsteps = int(Tmax/dt)

    T = exact_solution(x, 0)
    time = 0.0

    for n in range(nsteps):
        t = n*dt
        F = source_term(x, t)
        ux = np.zeros_like(T)
        uxx = np.zeros_like(T)
        for j in range(1, NX-1):
            ux[j] = (T[j+1]-T[j-1])/(2*dx)
            uxx[j] = (T[j+1]-2*T[j]+T[j-1])/(dx**2)
        RHS = -V*ux + K*uxx - lamda*T + F
        T[1:-1] += dt * RHS[1:-1]

        # Erreur à T/2
        if abs(t - Tmax/2) < dt/2:
            Tex = exact_solution(x, t)
            Err_T2.append(np.sqrt(np.sum((T-Tex)**2)*dx))

    # Erreur finale à T
    Tex = exact_solution(x, Tmax)
    Err_Tfin.append(np.sqrt(np.sum((T-Tex)**2)*dx))

# ------------------------------------------------------------
# Tracés et sauvegarde
# ------------------------------------------------------------
plt.figure(figsize=(8,5))
plt.plot(NX_list, Err_T2, 'o-', label='Erreur à T/2')
plt.plot(NX_list, Err_Tfin, 's-', label='Erreur à T')
plt.xlabel('Nombre de points NX')
plt.ylabel('Erreur L2')
plt.title('Erreur selon le maillage - ADR instationnaire')
plt.legend()
plt.grid(True)

# Sauvegarde automatique
plt.savefig("error_L2_mesh.png", dpi=300)
plt.show()


