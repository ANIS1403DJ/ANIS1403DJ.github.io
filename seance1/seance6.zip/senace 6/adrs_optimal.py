# optim_adrs_all_figures.py
import math
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize

def ADRS(NX, xcontrol, Target=None, Time=20.0, store_res=False):
    """
    Résout l'équation ADRS 1D (schéma explicite simple) avec sources pondérées par xcontrol.
    Retourne cost, T, x et éventuellement la liste des résidus (rest) pour tracer la convergence.
    """
    # Paramètres physiques
    K = 0.1     # Diffusion coefficient
    L = 1.0     # Domain size
    V = 1.0
    lamda = 1.0

    # Paramètres numériques
    NT = 10000
    eps = 1e-6   # critère de convergence relatif

    dx = L / (NX - 1)
    dt = 0.5 * dx**2 / (abs(V)*dx + 2*K + 1e-12)

    x = np.linspace(0.0, L, NX)
    T = np.zeros(NX)
    F = np.zeros(NX)
    RHS = np.zeros(NX)

    # Construction du terme source
    for j in range(1, NX-1):
        for ic in range(len(xcontrol)):
            F[j] += xcontrol[ic] * np.exp(-100.0 * (x[j] - L / (ic + 1))**2)

    # Intégration en temps
    n = 0
    res = 1.0
    res0 = 1.0
    rest = []
    while n < NT and res > eps * res0:
        n += 1
        res = 0.0
        for j in range(1, NX-1):
            xnu = K + 0.5 * dx * abs(V)
            Tx = (T[j+1] - T[j-1]) / (2*dx)
            Txx = (T[j-1] - 2*T[j] + T[j+1]) / (dx**2)
            RHS[j] = dt * (-V * Tx + xnu * Txx - lamda * T[j] + F[j])
            res += abs(RHS[j])
        for j in range(1, NX-1):
            T[j] += RHS[j]
            RHS[j] = 0.0
        if n == 1:
            res0 = max(res, 1e-12)
        rest.append(res)
        if not np.isfinite(res):
            raise RuntimeError("Solution diverge : ajuster dt ou NX.")

    cost = None
    if Target is not None:
        cost = np.dot(T - Target, T - Target) * dx

    if store_res:
        return cost, T, x, rest
    else:
        return cost, T, x

def interp_to_ref(x_src, u_src, x_ref):
    """Interpolation linéaire (numpy.interp) de u_src(x_src) vers x_ref."""
    return np.interp(x_ref, x_src, u_src)

def assemble_A_B_on_ref(NX_ref, solutions, target_ref, dx_ref):
    """Assemblage des matrices A et B sur la grille de référence."""
    x_ref = np.linspace(0.0, 1.0, NX_ref)
    nbc = len(solutions['ui'])
    u0_ref = interp_to_ref(solutions['u0'][0], solutions['u0'][1], x_ref)
    ui_ref = [interp_to_ref(solutions['ui'][k][0], solutions['ui'][k][1], x_ref) for k in range(nbc)]
    A = np.zeros((nbc, nbc))
    B = np.zeros(nbc)
    for i in range(nbc):
        for j in range(i, nbc):
            A[i, j] = np.dot(ui_ref[i], ui_ref[j]) * dx_ref
            A[j, i] = A[i, j]
        B[i] = np.dot(ui_ref[i], (target_ref - u0_ref)) * dx_ref
    return A, B, u0_ref, ui_ref, x_ref

# Paramètres
nbc = 6
NX0 = 30
nb_iter_refine = 4

best_cost = 1e20
x_best = np.zeros(nbc)
cost_tab = np.zeros(nb_iter_refine)
NX_tab = np.zeros(nb_iter_refine)
x_hist = []

# Boucle de raffinement
for irefine in range(nb_iter_refine):
    NX = NX0 + 5 * irefine
    NX_tab[irefine] = NX
    dx = 1.0 / (NX - 1)

    # Solution cible
    xcible = np.arange(nbc) + 1.0
    cost_tmp, Target, x_target = ADRS(NX, xcible)

    # Solutions de base
    solutions = {}
    cost0, u0, x0 = ADRS(NX, np.zeros(nbc))
    solutions['u0'] = (x0, u0)
    solutions['ui'] = []
    for ic in range(nbc):
        xic = np.zeros(nbc)
        xic[ic] = 1.0
        _, uic, xic_grid = ADRS(NX, xic)
        solutions['ui'].append((xic_grid, uic))

    # Grille de référence
    NX_ref = NX
    dx_ref = dx
    x_ref = np.linspace(0.0, 1.0, NX_ref)
    target_ref = interp_to_ref(x_target, Target, x_ref)

    A, B, u0_ref, ui_ref, x_ref = assemble_A_B_on_ref(NX_ref, solutions, target_ref, dx_ref)

    # Résolution A x = B
    try:
        xopt = np.linalg.solve(A, B)
    except np.linalg.LinAlgError:
        reg = 1e-8 * np.eye(nbc)
        xopt = np.linalg.solve(A + reg, B)

    print(f"Raffinement {irefine+1}: NX={NX}, xopt={xopt}")
    x_hist.append(xopt)

    cost_opt, Topt, _ = ADRS(NX, xopt, Target)
    cost_tab[irefine] = cost_opt

    if cost_opt < best_cost:
        best_cost = cost_opt
        x_best = xopt.copy()
        T_best = Topt.copy()
        Target_best = Target.copy()

# --- Figure 1 : Convergence du coût ---
plt.figure(figsize=(6, 4))
plt.plot(NX_tab, np.log10(cost_tab), marker='o', color='b')
plt.xlabel("Taille du maillage NX")
plt.ylabel("log10(J(X*(h)))")
plt.title("Convergence du coût")
plt.grid(True)

# --- Figure 2 : Solution optimisée vs cible ---
plt.figure(figsize=(6, 4))
x_plot = np.linspace(0.0, 1.0, len(T_best))
plt.plot(x_plot, T_best, label="T_opt (optim linéaire)", lw=2)
plt.plot(x_plot, Target_best, label="Target", ls='--')
plt.xlabel("x")
plt.ylabel("T")
plt.title("Solution optimisée vs cible")
plt.legend()
plt.grid(True)

# --- Figure 3 : Évolution des composantes x_i(h) ---
plt.figure(figsize=(6, 4))
for i in range(nbc):
    plt.plot(NX_tab, [x_hist[k][i] for k in range(nb_iter_refine)], marker='o', label=f"x{i+1}")
plt.xlabel("NX")
plt.ylabel("x_i(h)")
plt.title("Évolution des composantes du contrôle optimal")
plt.legend()
plt.grid(True)

# --- Figure 4 : Convergence temporelle (résidu) ---
_, _, _, rest = ADRS(40, np.zeros(nbc), store_res=True)
plt.figure(figsize=(6, 4))
plt.semilogy(rest)
plt.xlabel("Itérations temporelles")
plt.ylabel("Résidu (somme |RHS|)")
plt.title("Convergence temporelle ADRS (exemple)")
plt.grid(True)

plt.show()

print("\n✅ Simulation terminée.")
print("Meilleure solution trouvée :")
print("x_best =", x_best)
print("Coût minimal =", best_cost)

